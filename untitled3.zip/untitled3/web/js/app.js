

$(document).ready(function() {

    $("#sub").click(

    function(){
        alert("dddd");
        $.ajax({
            //type:"post",//����ʽ
  url:"/Javaweb/GetyyPage",//���������ַ
  //contentType: 'application/json',
   //dataType:'json',
   data:{//���͸����ݿ������
   age:$("#age").val(),
   sex:$('input[name="sex"]:checked').val(),
   hurttype:$("#hurttype").val(),
   trestbps:$("#trestbps").val(),
   chol:$("#chol").val(),
   fbs:$('input[name="fbs"]:checked').val(),
   restecg:$("#restecg").val(),
   thalach:$("#thalach").val(),
   exang:$('input[name="exang"]:checked').val(),
   oldpeak:$("#oldpeak").val(),
   slope:$("#slope").val(),
   ca:$("#ca").val(),
   thal:$("#thal").val(),
   file1:$("#file1").val(),
    file2:$("#file2").val(),
   hxb:$('input[name="hxb"]:checked').val(),
   nb:$('input[name="nb"]:checked').val(),
   nbtk:$('input[name="nbtk"]:checked').val(),
   xj:$('input[name="xj"]:checked').val(),
   xt:$("#xt").val(),
   xns:$("#xns").val(),
   xjg:$("#xjg").val(),
   hxbjs:$("#hxbjs").val(),
   gxy:$('input[name="gxy"]:checked').val(),
   tnb:$('input[name="tnb"]:checked').val(),
   sy:$('input[name="sy"]:checked').val(),
   zsz:$('input[name="zsz"]:checked').val(),
   px:$('input[name="px"]:checked').val()
   },
   //����ɹ���Ļص�������һ������
   success:function(data){
    $("#resText").val(data);
   }
        });
    }
    );


    });